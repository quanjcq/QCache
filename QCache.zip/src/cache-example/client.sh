#!/usr/bin/env bash
java -jar ./artifacts_1/QCache_jar/QCache.jar runClient $1


