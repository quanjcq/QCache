package core.cache;

import java.io.Serializable;

/**
 * 存放数据的实体
 */
public interface CacheDataI{
}
