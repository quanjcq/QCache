package core.message;

public class RaftHeartMessage extends RaftMessage{

}
