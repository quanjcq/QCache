package constant;

public class RaftCommandMethod {
    public static final String add= "add";
    public static final String remove = "remove";
}
